<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ItemsController;

use App\Http\Controllers\FeedbackController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('root');


Route::get('/faq', function () {
    return view('faq');
})->name('faq');


Route::get('/checkout', function () {
    return view('checkout');
})->name('checkout');




Route::get('/menu',[ItemsController::class,'getData'])->name('menu');

// Route::get('/menu', function () {
//     return view('menu');
// });

Route::get('/feedback', function () {


    return view('feedback');
})->middleware(['auth','verified'])->name('feedback');

Route::post('feedback',[FeedbackController::class,'addreviews']);



// Route::get('menu', [fastfoodController::class,'index']);

//Route::get('/menu', [fastfoodController::class,'show']);    //this thing is same as the line below 

// Route::get('/menu', 'App\Http\Controllers\fastfoodController@index');   // this has same meaning as the line above 

// Route::get('/menu',[shakecontroller::class,'show']);


// Route::get('/menu/{id}', function (Request $request, $id) {
//     return 'menu'.$id;
// });




// Route::get('menu', function () {


//     return view('menu');
// })->name('menu');


Route::get('/contact', function () {


    return view('contact');
})->name('contact');






//Route:: get('/get-data',[UserController::class,'index']);


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth','verified'])->name('dashboard');


// Route::get('privacy', function () {
//         return view('privacy');
//     })->middleware(['auth','verified'])->name('privacy');

Route::get('/privacy', function () {
         return view('privacy');
    })->name('privacy');

    Route::get('/terms', function () {
         return view('terms');
    })->name('terms');




// Route::get('terms', function () {
//     return view('terms');
//     })->middleware(['auth','verified'])->name('terms');




require __DIR__.'/auth.php';


// Route::group(['middleware' => ['auth','verified']], function() {
//     Route::get('/home', 'HomeController@index')->name('home');
//     Route::resource('/blog', 'BlogController');
//     Route::resource('/category', 'CategoryController');
// });