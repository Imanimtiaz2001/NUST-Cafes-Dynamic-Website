
<!DOCTYPE html>
<html>
    <head>
       <!--Favicon-->
    <link rel="icon"  href="{{ asset('restaurant.png') }}">

        <!--Styling-->
        <style>

            @import url('http://fonts.cdnfonts.com/css/montserrat');

            *{
              font-family: Montserrat;
            }

          *, *::before, *::after {
            box-sizing: border-box;
            margin:0;
            padding:0;
          }

          body, button {
            font-family:montserrat ;
          }

          body {
            background-color: rgb(221, 221, 221);
          }
h3,h4
{
  color:#b0171f;
}
.main {
          background-color: white;
          width:75%;
          box-shadow: 0 0 10px rgb(206, 206, 206);
          display:block;
          margin:auto;
          padding:30px;
        }
p{ 
  text-align: center;
}
        .feedback {
          font-size: 60px;
          padding-top :20px;;
          text-align: center;
          color: #b0171f;
        }
        .separate {
        width:50%;
        margin:auto;
        }
        #form{
                margin:auto;
                margin-top: 2%;
                margin-bottom: 3%;
                margin-left: 100px;
                margin-right: 100px;
                padding: 20px;
                box-shadow: 2px 2px 10px gray ;
                border-width: 1px;
            }
           
            #responsetext{
                font-size: 25px;
                margin-top: 1%;
                margin-left: 2%;
            }
            #responsebox{
                font-size: 17px;
                height: 30px;
                padding: 5px;
            } #select{
                font-size: 17px;
                padding: 9.5px;
                width: 97.9%;
            }
          
            #SubmitButton{
                font-size: 17px;
                font-weight: 600;
                margin-top: 1%;
                margin-bottom: 2%;
                width: 83px;
                height: 37px;
                transition-duration: 0.3s;
                border-radius: 10px;
            }
            #Subject{
                
                width: 97%;
                font-size: 17px;
                height: 100px;
                padding: 5px;
            }
            button:hover{
              background-color: #b0171f;
              color: white;
            }
           
div {
  padding-top: 5px;
  padding-right: 5px;
  padding-bottom:5px;
  padding-left: 5px;
}
</style>

    <!--Page title-->
    <title>Feedback Form</title>
 
    <body>     
      
     
      <!--Intro-->
      <div class="main">
        <h1 class="feedback">FEEDBACK FORM</h1><br>
        <hr class="separate"><br>
        <p>We would love to hear your <b><i>thoughts, suggestions, concerns or problems</i></b> with anything so we can improve it!</p>
        <br>
      
      <!--Feedback form-->
      <div id="form">
       
        <form id="responsetext" method="POST" action="feedback">
          @csrf
         <br> <h3 >Feedback Type</h3>
           <input type="radio"id="comment" name="feedback_type" value="Comments" >
           <label for="comment">Comments &ensp;</label>
          <input type="radio"  id="suggestions" name="feedback_type" value="Suggestions">
          <label for="suggestions">Suggestions &ensp;</label>
          <input type="radio" id="question" name="feedback_type" value="Questions">
          <label for="question">Questions &ensp;</label>
          <input type="radio"id="complain" name="feedback_type" value="Complains">
          <label for="complain">Complains </label>
        
          <br>
            <h4>Name:</h4>
            <input id="responsebox" name="Firstname" type="text" placeholder="First Name">
            <input id="responsebox" name="lastname" type="text" placeholder="Last Name"><br><br>
            <h4>Email Address:</h4>
            <input id="responsebox" name="email"  type="text" placeholder="Email Address"><br><br>
            <h4>Campus:</h4>
            <select id="select" name="campus">
                <option>SEECS</option> 
                <option>S3H</option>
                <option>NICE</option> 
                <option>ASAB</option>
                <option>SADA</option>
                <option>NBS</option>
                <option>RIMMS</option>
                <option>CIPS</option>
                <option>SCME</option>
                <option>IESE</option>
                <option>IAEC</option> 
                <option>SNS</option>   
                <option>SMME</option>               
            </select><br><br>
            <h4>Cafe:</h4>
            <select id="select" name="cafe">
                <option>CONCORDIA 1</option> 
                <option>CONCORDIA 2</option>
                <option>CONCORDIA 3</option> 
                <option>CONCORDIA 4</option>
                <option>COFFEE SHOP</option>
                <option>MARGALLA</option>
                <option>DREAM VILLE</option>
                <option>KYBO</option>
                <option>RETRO</option>        
            </select><br><br>
            <h4>Subject:</h4>
            <textarea id="Subject" name="subject" placeholder="Write something..."></textarea><br>
            <button id="SubmitButton">Submit</button>
        </form>
    </div>
</div>
  </body>

</html>


