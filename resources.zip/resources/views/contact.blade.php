<!DOCTYPE html>
<html>
    <head>
        <!--Styling-->
        <style>

          @import url('http://fonts.cdnfonts.com/css/montserrat');

              *{
                font-family: Montserrat;
              }


          *, *::before, *::after {
            box-sizing: border-box;
            margin:0;
            padding:0;
          }

          body {
            background-color: rgb(221, 221, 221);
          }
h1
{
  text-align: center;
  color:#b0171f;
}
h2{
  color:#b0171f;
}
.main {
          background-color: white;
          width:75%;
          box-shadow: 0 0 10px rgb(206, 206, 206);
          display:block;
          margin:auto;
          padding:30px;

        }
        .contactus {
          font-size: 60px;
          padding-top :20px;;
          text-align: center;
          color: #b0171f;
        }
        .separate {
        width:50%;
        margin:auto;
        }
        #contactpage{
                margin:auto;
                margin-top: 2%;
                margin-bottom: 3%;
                margin-left: 100px;
                margin-right: 100px;
                padding: 20px;
                box-shadow: 2px 2px 10px gray ;
                border-width: 1px;
            }
            #contact{
                font-size: 40px;
                margin-top: 1.5%;
                margin-left: 5%;
                color:#b0171f;
            }
          .mainpara{ 
  text-align: center;
}
           
            .flex-container {
              display: flex;
flex-direction: row;
border: 2px solid #b0171f;
}
#flex-item-left {
  padding-top: 12px;
  padding-left: 8px;
font-size: 25px;
flex: 80%;
}
.flex-item-right {
  width:50px;
height: 50px;
flex: 20%;
}
#concordia1
{
  display: none;
}
#concordia2
{
  display: none;
}
#concordia3
{
  display: none;
}
#concordia4
{
  display: none;
}
#margalla
{
  display: none;
}
#dreamville
{
  display: none;
}
#kybo
{
  display: none;
}
#retro
{
  display: none;
}

</style>


    <!--Page title-->
    <title>Contact Us</title>
     <!--Favicon-->
    <link rel="icon"  href="{{ asset('restaurant.png') }}">
    <script type="text/javascript" >
      function changedisplayC1(src) {
        var x = document.getElementById("concordia1");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            }
      function changedisplayC2(src) {
        var x = document.getElementById("concordia2");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            }        
            function changedisplayC3(src) {
        var x = document.getElementById("concordia3");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            }
            function changedisplayC4(src) {
        var x = document.getElementById("concordia4");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            } 
            function changedisplayMargalla(src) {
        var x = document.getElementById("margalla");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            }
            function changedisplayDreamville(src) {
        var x = document.getElementById("dreamville");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            }
            function changedisplayKybo(src) {
        var x = document.getElementById("kybo");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            }
            function changedisplayRetro(src) {
        var x = document.getElementById("retro");
        if (x.style.display.match("block")) {
          x.style.display = "none";}
           else {
             x.style.display = "block";}
            } 
    </script>
    <body>     
      
     
      <!--Intro-->
      <div class="main">
        <h1 class="contactus">CONTACT US</h1><br>
        <hr class="separate"><br>
        <p class="mainpara">Click on the <b><i>cafe </b></i>to see its details!</p>
        <br>
        <div id="contactpage">
            <h1>NUST CAFES DETAILS</h1><br><br>
            <div class="flex-container"  >
            <p  id="flex-item-left" >CONCORDIA 1  <p> 
              <img class="flex-item-right" onclick=changedisplayC1(this) src="dropdownimg.jpeg" /> 
            </div>
            <div id="concordia1"><h2 >Location:</h2><p>Near SADA,IESE<p> 
              <h2>Email</h2><p>c1@gmail.com<p> 
                <h2>Contact Number</h2><p>0315-2134544<p> </div> 
                  <br><div class="flex-container"  >
                  <p  id="flex-item-left" >CONCORDIA 2 <p> 
                    <img class="flex-item-right" onclick=changedisplayC2(this) src="dropdownimg.jpeg" /> 
                  </div>
                  <div id="concordia2"><h2 >Location:</h2><p>Near SEECS,IEAC,RIMMS<p> 
                    <h2>Email</h2><p>c2@gmail.com<p> 
                      <h2>Contact Number</h2><p>0300-2345654<p> </div>  
           <br><div class="flex-container"  >
                        <p  id="flex-item-left" >CONCORDIA 3  <p> 
                          <img class="flex-item-right" onclick=changedisplayC3(this) src="dropdownimg.jpeg" /> 
                        </div>
                        <div id="concordia3"><h2 >Location:</h2><p>Near NUST CENTRAL LIBRARY<p> 
                          <h2>Email</h2><p>c3@gmail.com<p> 
                            <h2>Contact Number</h2><p>0312-8473404<p> </div>
              <br><div class="flex-container"  >
              <p  id="flex-item-left" >CONCORDIA 4  <p> 
                 <img class="flex-item-right" onclick=changedisplayC4(this) src="dropdownimg.jpeg" /> 
                    </div>
                    <div id="concordia4"><h2 >Location:</h2><p>Near SMME,SNS<p> 
                    <h2>Email</h2><p>c4@gmail.com<p> 
                    <h2>Contact Number</h2><p>0305-3498913<p> </div>  
    <br> <div class="flex-container"  >
          <p  id="flex-item-left" >MARGALLA  <p> 
           <img class="flex-item-right" onclick=changedisplayMargalla(this) src="dropdownimg.jpeg" /> 
             </div>
              <div id="margalla"><h2 >Location:</h2><p>Near C1,ASAB,IESE<p> 
                  <h2>Email</h2><p>margalla@gmail.com<p> 
                  <h2>Contact Number</h2><p>0315-7832983<p> </div>    
      <br> <div class="flex-container"  >
                      <p  id="flex-item-left" >DREAM VILLE <p> 
                        <img class="flex-item-right" onclick=changedisplayDreamville(this) src="dropdownimg.jpeg" /> 
                      </div>
                      <div id="dreamville"><h2 >Location:</h2><p>Near C1,IESE<p> 
                        <h2>Email</h2><p>dreamville@gmail.com<p> 
                          <h2>Contact Number</h2><p>0308-8394822<p> </div>

        <br><div class="flex-container"  >
                              <p  id="flex-item-left" >KYBO  <p> 
                                <img class="flex-item-right" onclick=changedisplayKybo(this) src="dropdownimg.jpeg" /> 
                              </div>
                              <div id="kybo"><h2 >Location:</h2><p>Near SECCES,C2<p> 
                                <h2>Email</h2><p>kybo@gmail.com<p> 
                                  <h2>Contact Number</h2><p>0312-4821982<p> </div>     
               <br><div class="flex-container"  >
                                      <p  id="flex-item-left" >RETRO  <p> 
                                        <img class="flex-item-right" onclick=changedisplayRetro(this) src="dropdownimg.jpeg" /> 
                                      </div>
                                      <div id="retro"><h2 >Location:</h2><p>Near RUMI HOSTELS<p> 
                                        <h2>Email</h2><p>retro@gmail.com<p> 
                                          <h2>Contact Number</h2><p>0315-3929838<p> </div>
    </div>
  </div>
</div>
  </body>
  
</html>
