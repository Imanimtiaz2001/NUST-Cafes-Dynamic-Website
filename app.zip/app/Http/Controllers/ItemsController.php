<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Item;
use App\Models\Cafe;

class ItemsController extends Controller
{
    public function getData()
    {

        $data = Item::where('id','B00001')->get();
      //  $collection=Breakfastitem::all();
        // return Breakfastitem::where('breakfastitem_id','B00001')->get();
       // return view('menu',['collection'=>$data['data']]);
       $data2 =Item::where('id','B00002')->get();
       $data3 =Item::where('id','B00003')->get();
       $data4 =Item::where('id','B00004')->get();
       $data5 =Item::where('id','B00005')->get();
       $data6 =Item::where('id','B00006')->get();
       $data7 =Item::where('id','B00007')->get();
       $data8 =Item::where('id','DL00001')->get();
       $data9 =Item::where('id','DL00002')->get();
       $data10 =Item::where('id','DL00003')->get();
       $data11 =Item::where('id','DL00004')->get();
       $data12 =Item::where('id','DL00010')->get();
       $data13 =Item::where('id','DL00006')->get();
       $data14 =Item::where('id','DL00007')->get();
       $data15 =Item::where('id','SJ00001')->get();
       $data16 =Item::where('id','SJ00002')->get();
       $data17 =Item::where('id','SJ00003')->get();
       $data18 =Cafe::where('Cafeid','12')->get();




       return view('menu',compact('data','data2','data3','data4','data5','data6','data7','data8','data9','data10','data11','data12','data13','data14','data15','data16','data17','data18'));
    }


    public function addtoCart(Request $res )
    {
        if($res->session()->has())
        {

        }
    }
}
