
  
  
  

          <div class="col-md-5 order-md-1">
            <svg
              class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto"
              width="400"
              height="400"
              xmlns="http://www.w3.org/2000/svg"
              role="img"
              aria-label="Placeholder: 500x500"
              preserveAspectRatio="xMidYMid slice"
              focusable="false"
            >
              <rect width="100%" height="100%" fill="#eee" />
              <text x="50%" y="50%" fill="#aaa" dy=".3em"></text>
              <image href="https://img.freepik.com/free-vector/secure-login-concept-illustration_114360-4685.jpg?size=338&ext=jpg&ga=GA1.2.1475841289.1632755642" height="400" width="400"/>
              </svg>
          
            </div><?php /**PATH C:\wamp64\www\CafeCravings\resources\views/components/application-logo.blade.php ENDPATH**/ ?>