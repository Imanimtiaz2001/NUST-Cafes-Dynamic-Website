README FILE

Steps to include database in phpMyAdmin

1. Install Wampp.
2. Make sure all the three services are running.
3. With the installation of Wampp, phpMyAdmin will be installed automatically.
4. In the search bar in your preferred browser, type "localhost/phpmyadmin".
5. The front page of phpMyAdmin login page will appear, asking for username and passwork and service choice between MySQL and MariaDB.
6. Write "root" for username and leave password field blank.
7. Choose mySQL as the service choice.
8. The front page of phpMyAdmin will appear.
9. On the panel to the left, click on "New".
10. The Databases tab will appear.
11. Input database name.
12. Click on "Create" button.
13. Database is now created.
14. Clicking on database makes it the default database.
15. Options to make the database are now available.
16. To get SQL file, click on "export" tab at the top.
17. Select your export method.
18. Click on "go" to generate SQL file.


If an SQL already exists with database:
1. Go to phpMyAdmin and click on "import" tab.
2. Select the SQL file to be imported.
3. Click on "go".
4. Queries will be run and database will be created.


Steps for creating database in Laravel 
1. The very first thing is to open the .env file 
2. Change the default settings of these fields according to your database 
E.g. in our case:

DB_DATABASE=cafecravings
DB_USERNAME=root
DB_PASSWORD=


3. Also, go to the file "database.php" which is present in the folder "config".
4. Change the name of database, username and password and set it acccording to your database 

            'database' => env('DB_DATABASE', 'cafecravings'),
            'username' => env('DB_USERNAME', 'root'),
            'password' => env('DB_PASSWORD', ''),

5. Now, create a migration by writing "php artisan make:migration create_table_nameoftable" 
6. The migration of that table is created with "createdat" and "updatedat" fields and id 
7. Fields can be added in the table by writing "$table->string(name,length)"
8. After this, write in the command line "php artisan migrate" 
9. After migration, the table is created with the desired fields 
10. Create a model in the "models" folder by writing the command  "php artisan make:model" (table name i.e., singular) plural case will be used in the phpmyadmin 
11. You can manipulate and run queries on the tables of a database now


FOR ALREADY CREATED TABLES IN PHP MYADMIN AND USE IN LARAVEL 
Using Eloquent ORM Model, data of desired tables can be created in phpMyAdmin 
1. Create the model by writing the commmand "php artisan make:model (nameofmodel)"
2. If the table name in php is Cafe's, write the model of your name as Cafe i.e., use Snakecase; also, if you have name of your table other than Cafes like Cafe_List so specify it in the model class by writing the command 
"protected $table = 'Cafe_List';"
So, by this method you can use any table under the model by specifying it explicity in the model class 
3. If the primary key name is not id i.e., if it is cafe_id specify it as well
"protected $primarykey = 'contact_id';"
By default, in Laravel, the tables have timestamps i.e., "createdat" and "updatedat" columns. If this is not required, write:
"public $timestamps =false;"

Now, the Model is set up so by making a controllerclass in the "controller" folder and including the model in the controller which you want to use. You can write the business logic or queries in the controller and by creating a route you can view the data in the blades 
The route shoukd have the controller class and function parameters with it to reference in the blade or view file.






